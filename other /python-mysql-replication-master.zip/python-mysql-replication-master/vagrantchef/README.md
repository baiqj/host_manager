For managing a test environement with multiple versions of MySQL we use Vagrant and Chef. This directory contains all the cookbooks for building your environment.

Librarian
==========

Cookbooks are manage via [librarian](https://github.com/applicationsonline/librarian).

For installing it:

    gem instal librarian-chef
    librarian-chef install
