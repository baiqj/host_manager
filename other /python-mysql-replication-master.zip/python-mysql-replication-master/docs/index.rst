.. Python MySQL Replication documentation master file, created by
   sphinx-quickstart on Sun Sep 30 15:04:27 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Python MySQL Replication's documentation!
====================================================
Pure Python Implementation of MySQL replication protocol build on top of PyMYSQL 

Contents:

.. toctree::
    :maxdepth: 2

    binlogstream
    events
    examples
    support
    licence

Contributing
==============
You can report issues and contribute to the project on:
https://github.com/noplay/python-mysql-replication

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

