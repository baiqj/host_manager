###################
BinLogStreamReader
###################


.. automodule:: pymysqlreplication.binlogstream
    :members:
