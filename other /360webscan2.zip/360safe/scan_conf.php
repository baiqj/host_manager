<?php
define("WEBSCAN_KEY", "e2ca4be49b0402ae40eccf3fb045170f");
define("WEBSCAN_VERSION", "1.6");
date_default_timezone_set('GMT');
ini_set('display_errors', '0');
?>
